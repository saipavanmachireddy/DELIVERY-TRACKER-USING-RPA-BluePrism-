README:


*The Input and output File should be in the Following  Address

C:\Program Files\Blue Prism Limited

*Input file should contain two Columns with empty filled (Status,Time)
 those are our Target Coulmn.

*The Output file should contain the folloing sheet names
1.AWOT
2.FJ
3.DH
4.JSI


*Input file Name:     "delivery tracking"
*Output file Name:  "OUTPUTFILE"
* You should have permissions to access and modify files in the Above Mentioned Location.
*NetConnections Should be Stable Because We are handling wit The Web applicatins.
*All the best NOw you are ready to Start Your Bot.

